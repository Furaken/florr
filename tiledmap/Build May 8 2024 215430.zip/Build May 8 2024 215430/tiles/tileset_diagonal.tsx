<tileset version="1.9" tiledversion="1.9.2" name="tileset_diagonal" tilewidth="1" tileheight="1" tilecount="0" columns="0"/>
,
   